#KRUIZ
#09.30.2024

#necessary packages
library(dplyr)
library(pdftools)
library(stringr)
library(tidyverse)
library(ggplot2)

#----
#creating a function to do what is needed
megaman = function(raw_data){
  #the first thing this function does is grab the part of the PDF that includes
  #all text in the content of a majority opinion and collapse all new lines so
  #that these do not mess with my regular expressions
  case_df <- str_extract(raw_data, "(?s)[:upper:]{1,}[:punct:]{1,} \\w{1,} Judge[:punct:]\\n\\s*(.*?)\\s*\\nAll Citations\\n")
  new <- data.frame(NA)
  new$judge <- str_extract(raw_data, "[:upper:]{1,}[:punct:]{1,} \\w{1,} Judge[:punct:]\\n")
  case_df <- str_replace_all(case_df, "[\n]" , " ")
  #I now capture all citatinos to cases
  a <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} U\\.S\\. \\d{1,}")
  a2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} U\\.S\\. \\d{1,}")
  dfa <- data.frame(c1 = a, c2 = a2)
  colnames(dfa)[1] ="citation"
  b <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} S\\.Ct\\. \\d{1,}")
  b2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} S\\.Ct\\. \\d{1,}")
  dfb <- data.frame (c1 = b, c2 = b2)
  colnames(dfb)[1] ="citation"
  c <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\. \\d{1,}")
  c2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\. \\d{1,}")
  dfc <- data.frame (c1 = c, c2 = c2)
  colnames(dfc)[1] ="citation"
  d <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\.2d \\d{1,}")
  d2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\.2d \\d{1,}")
  dfd <- data.frame (c1 = d, c2 = d2)
  colnames(dfd)[1] ="citation"
  e <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\.3d \\d{1,}")
  e2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\.3d \\d{1,}")
  dfe <- data.frame (c1 = e, c2 = e2)
  colnames(dfe)[1] ="citation"
  f <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\.4th \\d{1,}")
  f2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\.4th \\d{1,}")
  dff <- data.frame (c1 = f, c2 = f2)
  colnames(dff)[1] ="citation"
  g <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\. App'x\\. \\d{1,}")
  g2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\. App'x\\. \\d{1,}")
  dfg <- data.frame (c1 = g, c2 = g2)
  colnames(dfg)[1] ="citation"
  ga <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} Fed\\. Appx\\. \\d{1,}")
  ga2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} Fed\\. Appx\\. \\d{1,}")
  dfga <- data.frame (c1 = ga, c2 = ga2)
  colnames(dfga)[1] ="citation"
  gb <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} Fed\\. Appx\\. at \\d{1,}")
  gb2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} Fed\\. Appx\\. at \\d{1,}")
  dfgb <- data.frame (c1 = gb, c2 = gb2)
  colnames(dfgb)[1] ="citation"
  gc <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} Fed\\.Appx\\. \\d{1,}")
  gc2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} Fed\\.Appx\\. \\d{1,}")
  dfgc <- data.frame (c1 = gc, c2 = gc2)
  colnames(dfgc)[1] ="citation"
  gd <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} Fed\\.Appx\\. at \\d{1,}")
  gd2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} Fed\\.Appx\\. at \\d{1,}")
  dfgd <- data.frame (c1 = gd, c2 = gd2)
  colnames(dfgd)[1] ="citation"
  h <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\.Supp\\. \\d{1,}")
  h2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\.Supp\\. \\d{1,}")
  dfh <- data.frame (c1 = h, c2 = h2)
  colnames(dfh)[1] ="citation"
  i <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\.Supp\\.2d \\d{1,}")
  i2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\.Supp\\.2d \\d{1,}")
  dfi <- data.frame (c1 = i, c2 = i2)
  colnames(dfi)[1] ="citation"
  j <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\.Supp\\.3d \\d{1,}")
  j2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\.Supp\\.3d \\d{1,}")
  dfj <- data.frame (c1 = j, c2 = j2)
  colnames(dfj)[1] ="citation"
  k <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\. Supp\\. \\d{1,}")
  k2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\. Supp\\. \\d{1,}")
  dfk <- data.frame (c1 = k, c2 = k2)
  colnames(dfk)[1] ="citation"
  l <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\. Supp\\. 2d \\d{1,}")
  l2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\. Supp\\. 2d \\d{1,}")
  dfl <- data.frame (c1 = l, c2 = l2)
  colnames(dfl)[1] ="citation"
  m <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\. Supp\\. 3d \\d{1,}")
  m2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\. Supp\\. 3d \\d{1,}")
  dfm <- data.frame (c1 = m, c2 = m2)
  colnames(dfm)[1] ="citation"
  n <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} A\\. \\d{1,}")
  n2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} A\\. \\d{1,}")
  dfn <- data.frame (c1 = n, c2 = n2)
  colnames(dfn)[1] ="citation"
  o <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} A\\.2d \\d{1,}")
  o2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} A\\.2d \\d{1,}")
  dfo <- data.frame (c1 = o, c2 = o2)
  colnames(dfo)[1] ="citation"
  p <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} A\\.3d \\d{1,}")
  p2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} A\\.3d \\d{1,}")
  dfp <- data.frame (c1 = p, c2 = p2)
  colnames(dfp)[1] ="citation"
  q <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} P\\. \\d{1,}")
  q2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} P\\. \\d{1,}")
  dfq <- data.frame (c1 = q, c2 = q2)
  colnames(dfq)[1] ="citation"
  r <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} P\\.2d \\d{1,}")
  r2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} P\\.2d \\d{1,}")
  dfr <- data.frame (c1 = r, c2 = r2)
  colnames(dfr)[1] ="citation"
  s <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} P\\.3d \\d{1,}")
  s2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} P\\.3d \\d{1,}")
  dfs <- data.frame (c1 = s, c2 = s2)
  colnames(dfs)[1] ="citation"
  t <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} N\\.E\\. \\d{1,}")
  t2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} N\\.E\\. \\d{1,}")
  dft <- data.frame (c1 = t, c2 = t2)
  colnames(dft)[1] ="citation"
  u <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} N\\.E\\.2d \\d{1,}")
  u2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} N\\.E\\.2d \\d{1,}")
  dfu <- data.frame (c1 = u, c2 = u2)
  colnames(dfu)[1] ="citation"
  v <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} N\\.E\\.3d \\d{1,}")
  v2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} N\\.E\\.3d \\d{1,}")
  dfv <- data.frame (c1 = v, c2 = v2)
  colnames(dfv)[1] ="citation"
  w <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} N\\.W\\. \\d{1,}")
  w2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} N\\.W\\. \\d{1,}")
  dfw <- data.frame (c1 = w, c2 = w2)
  colnames(dfw)[1] ="citation"
  x <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} N\\.W\\.2d \\d{1,}")
  x2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} N\\.W\\.2d \\d{1,}")
  dfx <- data.frame (c1 = x, c2 = x2)
  colnames(dfx)[1] ="citation"
  y <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} N\\.W\\.3d \\d{1,}")
  y2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} N\\.W\\.3d \\d{1,}")
  dfy <- data.frame (c1 = y, c2 = y2)
  colnames(dfy)[1] ="citation"
  z <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} S\\.E\\. \\d{1,}")
  z2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} S\\.E\\. \\d{1,}")
  dfz <- data.frame (c1 = z, c2 = z2)
  colnames(dfz)[1] ="citation"
  aa <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} S\\.E\\.2d \\d{1,}")
  aa2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} S\\.E\\.2d \\d{1,}")
  dfaa <- data.frame (c1 = aa, c2 = aa2)
  colnames(dfaa)[1] ="citation"
  ab <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} S\\.E\\.3d \\d{1,}")
  ab2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} S\\.E\\.3d \\d{1,}")
  dfab <- data.frame (c1 = ab, c2 = ab2)
  colnames(dfab)[1] ="citation"
  ac <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} S\\.W\\ \\d{1,}")
  ac2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} S\\.W\\ \\d{1,}")
  dfac <- data.frame (c1 = ac, c2 = ac2)
  colnames(dfac)[1] ="citation"
  ad <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} S\\.W\\.2d \\d{1,}")
  ad2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} S\\.W\\.2d \\d{1,}")
  dfad <- data.frame (c1 = ad, c2 = ad2)
  colnames(dfad)[1] ="citation"
  ae <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} S\\.W\\.3d \\d{1,}")
  ae2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} S\\.W\\.3d \\d{1,}")
  dfae <- data.frame (c1 = ae, c2 = ae2)
  colnames(dfae)[1] ="citation"
  af <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} So\\. \\d{1,}")
  af2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} So\\. \\d{1,}")
  dfaf <- data.frame (c1 = af, c2 = af2)
  colnames(dfaf)[1] ="citation"
  ag <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} So\\.2d \\d{1,}")
  ag2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} So\\.2d \\d{1,}")
  dfag <- data.frame (c1 = ag, c2 = ag2)
  colnames(dfag)[1] ="citation"
  ah <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} So\\.3d \\d{1,}")
  ah2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} So\\.3d \\d{1,}")
  dfah <- data.frame (c1 = ah, c2 = ah2)
  colnames(dfah)[1] ="citation"
  ai <- str_extract_all(case_df, "\\d{1,} U\\.S\\. at \\d{1,}")
  ai2 <- str_locate_all(case_df, "\\d{1,} U\\.S\\. at \\d{1,}")
  dfai <- data.frame (c1 = ai, c2 = ai2)
  colnames(dfai)[1] ="citation"
  aj <- str_extract_all(case_df, "\\d{1,} S\\.Ct\\. at \\d{1,}")
  aj2 <- str_locate_all(case_df, "\\d{1,} S\\.Ct\\. at \\d{1,}")
  dfaj <- data.frame (c1 = aj, c2 = aj2)
  colnames(dfaj)[1] ="citation"
  ajj <- str_extract_all(case_df, "\\d{1,} S\\. Ct\\. at \\d{1,}")
  ajj2 <- str_locate_all(case_df, "\\d{1,} S\\. Ct\\. at \\d{1,}")
  dfajj <- data.frame (c1 = ajj, c2 = ajj2)
  colnames(dfajj)[1] ="citation"
  ak <- str_extract_all(case_df, "\\d{1,} F\\. at \\d{1,}")
  ak2 <- str_locate_all(case_df, "\\d{1,} F\\. at \\d{1,}")
  dfak <- data.frame (c1 = ak, c2 = ak2)
  colnames(dfak)[1] ="citation"
  al <- str_extract_all(case_df, "\\d{1,} F\\.2d at \\d{1,}")
  al2 <- str_locate_all(case_df, "\\d{1,} F\\.2d at \\d{1,}")
  dfal <- data.frame (c1 = al, c2 = al2)
  colnames(dfal)[1] ="citation"
  am <- str_extract_all(case_df, "\\d{1,} F\\.3d at \\d{1,}")
  am2 <- str_locate_all(case_df, "\\d{1,} F\\.3d at \\d{1,}")
  dfam <- data.frame (c1 = am, c2 = am2)
  colnames(dfam)[1] ="citation"
  an <- str_extract_all(case_df, "\\d{1,} F\\.4th at \\d{1,}")
  an2 <- str_locate_all(case_df, "\\d{1,} F\\.4th at \\d{1,}")
  dfan <- data.frame (c1 = an, c2 = an2)
  colnames(dfan)[1] ="citation"
  ao <- str_extract_all(case_df, "\\d{1,} F\\. App'x\\. at \\d{1,}")
  ao2 <- str_locate_all(case_df, "\\d{1,} F\\. App'x\\. at \\d{1,}")
  dfao <- data.frame (c1 = ao, c2 = ao2)
  colnames(dfao)[1] ="citation"
  ap <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:] \\d{1,} F\\.Supp\\. at \\d{1,}")
  ap2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:] \\d{1,} F\\.Supp\\. at \\d{1,}")
  dfap <- data.frame (c1 = ap, c2 = ap2)
  colnames(dfap)[1] ="citation"
  aq <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:] \\d{1,} F\\.Supp\\.2d at \\d{1,}")
  aq2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:] \\d{1,} F\\.Supp\\.2d at \\d{1,}")
  dfaq <- data.frame (c1 = aq, c2 = aq2)
  colnames(dfaq)[1] ="citation"
  ar <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:] \\d{1,} F\\.Supp\\.3d at \\d{1,}")
  ar2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:] \\d{1,} F\\.Supp\\.3d at \\d{1,}")
  dfar <- data.frame (c1 = ar, c2 = ar2)
  colnames(dfar)[1] ="citation"
  as <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:] \\d{1,} F\\. Supp\\. at \\d{1,}")
  as2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:] \\d{1,} F\\. Supp\\. at \\d{1,}")
  dfas <- data.frame (c1 = as, c2 = as2)
  colnames(dfas)[1] ="citation"
  at <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:] \\d{1,} F\\. Supp\\. 2d at \\d{1,}")
  at2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:] \\d{1,} F\\. Supp\\. 2d at \\d{1,}")
  dfat <- data.frame (c1 = at, c2 = at2)
  colnames(dfat)[1] ="citation"
  au <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:] \\d{1,} F\\. Supp\\. 3d at \\d{1,}")
  au2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:] \\d{1,} F\\. Supp\\. 3d at \\d{1,}")
  dfau <- data.frame (c1 = au, c2 = au2)
  colnames(dfau)[1] ="citation"
  av <- str_extract_all(case_df, "\\d{1,} A\\. \\d{1,}")
  av2 <- str_locate_all(case_df, "\\d{1,} A\\. \\d{1,}")
  dfav <- data.frame (c1 = av, c2 = av2)
  colnames(dfav)[1] ="citation"
  aw <- str_extract_all(case_df, "\\d{1,} A\\.2d \\d{1,}")
  aw2 <- str_locate_all(case_df, "\\d{1,} A\\.2d \\d{1,}")
  dfaw <- data.frame (c1 = aw, c2 = aw2)
  colnames(dfaw)[1] ="citation"
  ax <- str_extract_all(case_df, "\\d{1,} A\\.3d \\d{1,}")
  ax2 <- str_locate_all(case_df, "\\d{1,} A\\.3d \\d{1,}")
  dfax <- data.frame (c1 = ax, c2 = ax2)
  colnames(dfax)[1] ="citation"
  ay <- str_extract_all(case_df, "\\d{1,} P\\. \\d{1,}")
  ay2 <- str_locate_all(case_df, "\\d{1,} P\\. \\d{1,}")
  dfay <- data.frame (c1 = ay, c2 = ay2)
  colnames(dfay)[1] ="citation"
  az <- str_extract_all(case_df, "\\d{1,} P\\.2d \\d{1,}")
  az2 <- str_locate_all(case_df, "\\d{1,} P\\.2d \\d{1,}")
  dfaz <- data.frame (c1 = az, c2 = az2)
  colnames(dfaz)[1] ="citation"
  ba <- str_extract_all(case_df, "\\d{1,} P\\.3d \\d{1,}")
  ba2 <- str_locate_all(case_df, "\\d{1,} P\\.3d \\d{1,}")
  dfba <- data.frame (c1 = ba, c2 = ba2)
  colnames(dfba)[1] ="citation"
  bb <- str_extract_all(case_df, "\\d{1,} N\\.E\\. \\d{1,}")
  bb2 <- str_locate_all(case_df, "\\d{1,} N\\.E\\. \\d{1,}")
  dfbb <- data.frame (c1 = bb, c2 = bb2)
  colnames(dfbb)[1] ="citation"
  bc <- str_extract_all(case_df, "\\d{1,} N\\.E\\.2d \\d{1,}")
  bc2 <- str_locate_all(case_df, "\\d{1,} N\\.E\\.2d \\d{1,}")
  dfbc <- data.frame (c1 = bc, c2 = bc2)
  colnames(dfbc)[1] ="citation"
  bd <- str_extract_all(case_df, "\\d{1,} N\\.E\\.3d \\d{1,}")
  bd2 <- str_locate_all(case_df, "\\d{1,} N\\.E\\.3d \\d{1,}")
  dfbd <- data.frame (c1 = bd, c2 = bd2)
  colnames(dfbd)[1] ="citation"
  be <- str_extract_all(case_df, "\\d{1,} N\\.W\\. \\d{1,}")
  be2 <- str_locate_all(case_df, "\\d{1,} N\\.W\\. \\d{1,}")
  dfbe <- data.frame (c1 = be, c2 = be2)
  colnames(dfbe)[1] ="citation"
  bf <- str_extract_all(case_df, "\\d{1,} N\\.W\\.2d \\d{1,}")
  bf2 <- str_locate_all(case_df, "\\d{1,} N\\.W\\.2d \\d{1,}")
  dfbf <- data.frame (c1 = bf, c2 = bf2)
  colnames(dfbf)[1] ="citation"
  bg <- str_extract_all(case_df, "\\d{1,} N\\.W\\.3d \\d{1,}")
  bg2 <- str_locate_all(case_df, "\\d{1,} N\\.W\\.3d \\d{1,}")
  dfbg <- data.frame (c1 = bg, c2 = bg2)
  colnames(dfbg)[1] ="citation"
  bh <- str_extract_all(case_df, "\\d{1,} S\\.E\\. \\d{1,}")
  bh2 <- str_locate_all(case_df, "\\d{1,} S\\.E\\. \\d{1,}")
  dfbh <- data.frame (c1 = bh, c2 = bh2)
  colnames(dfbh)[1] ="citation"
  bi <- str_extract_all(case_df, "\\d{1,} S\\.E\\.2d \\d{1,}")
  bi2 <- str_locate_all(case_df, "\\d{1,} S\\.E\\.2d \\d{1,}")
  dfbi <- data.frame (c1 = bi, c2 = bi2)
  colnames(dfbi)[1] ="citation"
  bj <- str_extract_all(case_df, "\\d{1,} S\\.E\\.3d \\d{1,}")
  bj2 <- str_locate_all(case_df, "\\d{1,} S\\.E\\.3d \\d{1,}")
  dfbj <- data.frame (c1 = bj, c2 = bj2)
  colnames(dfbj)[1] ="citation"
  bk <- str_extract_all(case_df, "\\d{1,} S\\.W\\ \\d{1,}")
  bk2 <- str_locate_all(case_df, "\\d{1,} S\\.W\\ \\d{1,}")
  dfbk <- data.frame (c1 = bk, c2 = bk2)
  colnames(dfbk)[1] ="citation"
  bl <- str_extract_all(case_df, "\\d{1,} S\\.W\\.2d \\d{1,}")
  bl2 <- str_locate_all(case_df, "\\d{1,} S\\.W\\.2d \\d{1,}")
  dfbl <- data.frame (c1 = bl, c2 = bl2)
  colnames(dfbl)[1] ="citation"
  bm <- str_extract_all(case_df, "\\d{1,} S\\.W\\.3d \\d{1,}")
  bm2 <- str_locate_all(case_df, "\\d{1,} S\\.W\\.3d \\d{1,}")
  dfbm <- data.frame (c1 = bm, c2 = bm2)
  colnames(dfbm)[1] ="citation"
  bn <- str_extract_all(case_df, "\\d{1,} So\\. \\d{1,}")
  bn2 <- str_locate_all(case_df, "\\d{1,} So\\. \\d{1,}")
  dfbn <- data.frame (c1 = bn, c2 = bn2)
  colnames(dfbn)[1] ="citation"
  bo <- str_extract_all(case_df, "\\d{1,} So\\.2d \\d{1,}")
  bo2 <- str_locate_all(case_df, "\\d{1,} So\\.2d \\d{1,}")
  dfbo <- data.frame (c1 = bo, c2 = bo2)
  colnames(dfbo)[1] ="citation"
  bp <- str_extract_all(case_df, "\\d{1,} So\\.3d \\d{1,}")
  bp2 <- str_locate_all(case_df, "\\d{1,} So\\.3d \\d{1,}")
  dfbp <- data.frame (c1 = bp, c2 = bp2)
  colnames(dfbp)[1] ="citation"
  ge <- str_extract_all(case_df, "\\d{4} WL \\d{1,}")
  ge2 <- str_locate_all(case_df, "\\d{4} WL \\d{1,}")
  dfge <- data.frame (c1 = ge, c2 = ge2)
  colnames(dfge)[1] ="citation"
  gf <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} [:punct:]{1,} U\\.S\\. [:punct:]{1,}")
  gf2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} [:punct:]{1,} U\\.S\\. [:punct:]{1,}")
  dfgf <- data.frame (c1 = gf, c2 = gf2)
  colnames(dfgf)[1] ="citation"
  gg <- str_extract_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} S\\.Ct\\. at \\d{1,}")
  gg2 <- str_locate_all(case_df, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} S\\.Ct\\. at \\d{1,}")
  dfgg <- data.frame (c1 = gg, c2 = gg2)
  colnames(dfgg)[1] ="citation"

  preced_df <- data.frame(matrix(ncol = 3, nrow = 0))
  preced_df <- rbind(dfa, dfb, dfc, dfd, dfe, dff, dfg, dfh, dfi, dfj, dfk, dfl, dfm,
                     dfn, dfo, dfp, dfq, dfr, dfs, dft, dfu, dfv, dfw, dfx, dfy, dfz,
                     dfaa, dfab, dfac, dfad, dfae, dfaf, dfag, dfah, dfai, dfaj, dfak,
                     dfal, dfam, dfan, dfao, dfap, dfaq, dfar, dfas, dfat, dfau, dfav,
                     dfaw, dfax, dfay, dfaz, dfba, dfbb, dfbc, dfbd, dfbe, dfbf, dfbg,
                     dfbh, dfbi, dfbj, dfbk, dfbl, dfbm, dfbn, dfbo, dfbp, dfga, dfgb,
                     dfgc, dfgd, dfge, dfgf, dfgg, dfajj)
  preced_df <- preced_df %>% mutate(type = "precedential")

  #next I capture all the "ids" in my dataset
  bqq <- str_extract_all(case_df, "Id\\. .{1,2} \\d{1,}")
  bqq2 <- str_locate_all(case_df, "Id\\. .{1,2} \\d{1,}")
  dfbqq <- data.frame (c1 = bqq, c2 = bqq2)
  colnames(dfbqq)[1] ="citation"
  brr <- str_extract_all(case_df, "id\\. .{1,2} \\d{1,}")
  brr2 <- str_locate_all(case_df, "id\\. .{1,2} \\d{1,}")
  dfbrr <- data.frame (c1 = brr, c2 = brr2)
  colnames(dfbrr)[1] ="citation"
  bq <- str_extract_all(case_df, "Id\\. at \\d{1,}")
  bq2 <- str_locate_all(case_df, "Id\\. at \\d{1,}")
  dfbq <- data.frame (c1 = bq, c2 = bq2)
  colnames(dfbq)[1] ="citation"
  br <- str_extract_all(case_df, "id\\. at \\d{1,}")
  br2 <- str_locate_all(case_df, "id\\. at \\d{1,}")
  dfbr <- data.frame (c1 = br, c2 = br2)
  colnames(dfbr)[1] ="citation"
  bs <- str_extract_all(case_df, "Ibid\\.")
  bs2 <- str_locate_all(case_df, "Ibid\\.")
  dfbs <- data.frame (c1 = bs, c2 = bs2)
  colnames(dfbs)[1] ="citation"
  bt <- str_extract_all(case_df, "ibid\\.")
  bt2 <- str_locate_all(case_df, "ibid\\.")
  dfbt <- data.frame (c1 = bt, c2 = bt2)
  colnames(dfbt)[1] ="citation"
  bss <- str_extract_all(case_df, "Id\\.")
  bss2 <- str_locate_all(case_df, "Id\\.")
  dfbss <- data.frame (c1 = bss, c2 = bss2)
  colnames(dfbss)[1] ="citation"
  btt <- str_extract_all(case_df, "id\\.")
  btt2 <- str_locate_all(case_df, "id\\.")
  dfbtt <- data.frame (c1 = btt, c2 = btt2)
  colnames(dfbtt)[1] ="citation"
  bqqq <- str_extract_all(case_df, "Id\\. at .{1,2} \\d{1,}")
  bqqq2 <- str_locate_all(case_df, "Id\\. at .{1,2} \\d{1,}")
  dfbqqq <- data.frame (c1 = bqqq, c2 = bqqq2)
  colnames(dfbqqq)[1] ="citation"
  brrr <- str_extract_all(case_df, "id\\. at .{1,2} \\d{1,}")
  brrr2 <- str_locate_all(case_df, "id\\. at .{1,2} \\d{1,}")
  dfbrrr <- data.frame (c1 = brrr, c2 = brrr2)
  colnames(dfbrrr)[1] ="citation"

  ids_df <- data.frame(matrix(ncol = 3, nrow = 0))
  ids_df <- rbind(dfbq, dfbr, dfbs, dfbt, dfbqq, dfbrr, dfbss, dfbtt, dfbqqq, dfbrrr)
  ids_df <- ids_df %>% mutate(type = NA)

  #and the citations to legislative authority/agency actions
  bu <- str_extract_all(case_df, "U\\.S\\. CONST[:punct:]{1,} [Aa]rt\\. [:upper:]")
  bu2 <- str_locate_all(case_df, "U\\.S\\. CONST[:punct:]{1,} [Aa]rt\\. [:upper:]")
  dfbu <- data.frame (c1 = bu, c2 = bu2)
  colnames(dfbu)[1] ="citation"
  buu <- str_extract_all(case_df, "U\\.S\\. Const[:punct:]{1,} [Aa]rt\\. [:upper:]")
  buu2 <- str_locate_all(case_df, "U\\.S\\. Const[:punct:]{1,} [Aa]rt\\. [:upper:]")
  dfbuu <- data.frame (c1 = buu, c2 = buu2)
  colnames(dfbuu)[1] ="citation"
  bv <- str_extract_all(case_df, "U\\.S\\. CONST[:punct:]{1,} [Aa]mend")
  bv2 <- str_locate_all(case_df, "U\\.S\\. CONST[:punct:]{1,} [Aa]mend")
  dfbv <- data.frame (c1 = bv, c2 = bv2)
  colnames(dfbv)[1] ="citation"
  bvv <- str_extract_all(case_df, "U\\.S\\. Const[:punct:]{1,} [Aa]mend")
  bvv2 <- str_locate_all(case_df, "U\\.S\\. Const[:punct:]{1,} [Aa]mend")
  dfbvv <- data.frame (c1 = bvv, c2 = bvv2)
  colnames(dfbvv)[1] ="citation"
  bw <- str_extract_all(case_df, "U\\.S\\. CONST[:punct:]{1,} [Pp]mbl")
  bw2 <- str_locate_all(case_df, "U\\.S\\. CONST[:punct:]{1,} [Pp]mbl")
  dfbw <- data.frame (c1 = bw, c2 = bw2)
  colnames(dfbw)[1] ="citation"
  bww <- str_extract_all(case_df, "U\\.S\\. Const[:punct:]{1,} [Pp]mbl")
  bww2 <- str_locate_all(case_df, "U\\.S\\. Const[:punct:]{1,} [Pp]mbl")
  dfbww <- data.frame (c1 = bww, c2 = bww2)
  colnames(dfbww)[1] ="citation"
  bx <- str_extract_all(case_df, "[^S]{1,}\\. CONST[:punct:]{1,} [Aa]rt\\. [:upper:]")
  bx2 <- str_locate_all(case_df, "[^S]{1,}\\. CONST[:punct:]{1,} [Aa]rt\\. [:upper:]")
  dfbx <- data.frame (c1 = bx, c2 = bx2)
  colnames(dfbx)[1] ="citation"
  bxx <- str_extract_all(case_df, "[^S]{1,}\\. Const[:punct:]{1,} [Aa]rt\\. [:upper:]")
  bxx2 <- str_locate_all(case_df, "[^S]{1,}\\. Const[:punct:]{1,} [Aa]rt\\. [:upper:]")
  dfbxx <- data.frame (c1 = bxx, c2 = bxx2)
  colnames(dfbxx)[1] ="citation"
  by <- str_extract_all(case_df, "\\d{1,} U\\.S\\.C\\. .{1,2} \\d{1,}")
  by2 <- str_locate_all(case_df, "\\d{1,} U\\.S\\.C\\. .{1,2} \\d{1,}")
  dfby <- data.frame (c1 = by, c2 = by2)
  colnames(dfby)[1] ="citation"
  bz <- str_extract_all(case_df, "\\d{1,} U\\.S\\.C\\.A\\. .{1,2} \\d{1,}")
  bz2 <- str_locate_all(case_df, "\\d{1,} U\\.S\\.C\\.A\\. .{1,2} \\d{1,}")
  dfbz <- data.frame (c1 = bz, c2 = bz2)
  colnames(dfbz)[1] ="citation"
  ca <- str_extract_all(case_df, "\\d{1,} U\\.S\\.C\\. [Aa]pp\\. .{1,2} \\d{1,}")
  ca2 <- str_locate_all(case_df, "\\d{1,} U\\.S\\.C\\. [Aa]pp\\. .{1,2} \\d{1,}")
  dfca <- data.frame (c1 = ca, c2 = ca2)
  colnames(dfca)[1] ="citation"
  caa <- str_extract_all(case_df, "\\d{1,} U\\.S\\.C\\.[Aa]pp\\. .{1,2} \\d{1,}")
  caa2 <- str_locate_all(case_df, "\\d{1,} U\\.S\\.C\\.[Aa]pp\\. .{1,2} \\d{1,}")
  dfcaa <- data.frame (c1 = caa, c2 = caa2)
  colnames(dfcaa)[1] ="citation"
  cb <- str_extract_all(case_df, "[:alpha:]{1,}\\. CODE .{1,2} \\d{1,}")
  cb2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. CODE .{1,2} \\d{1,}")
  dfcb <- data.frame (c1 = cb, c2 = cb2)
  colnames(dfcb)[1] ="citation"
  cbb <- str_extract_all(case_df, "[:alpha:]{1,}\\.CODE .{1,2} \\d{1,}")
  cbb2 <- str_locate_all(case_df, "[:alpha:]{1,}\\.CODE .{1,2} \\d{1,}")
  dfcbb <- data.frame (c1 = cbb, c2 = cbb2)
  colnames(dfcbb)[1] ="citation"
  cbbb <- str_extract_all(case_df, "[:alpha:]{1,}\\. Code .{1,2} \\d{1,}")
  cbbb2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. Code .{1,2} \\d{1,}")
  dfcbbb <- data.frame (c1 = cbbb, c2 = cbbb2)
  colnames(dfcbbb)[1] ="citation"
  hn <- str_extract_all(case_df, "[:alpha:]{1,}\\.Code .{1,2} \\d{1,}")
  hn2 <- str_locate_all(case_df, "[:alpha:]{1,}\\.Code .{1,2} \\d{1,}")
  dfhn <- data.frame (c1 = hn, c2 = hn2)
  colnames(dfhn)[1] ="citation"
  cc <- str_extract_all(case_df, "[:alpha:]{1,}\\. STAT\\. .{1,2} \\d{1,}")
  cc2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. STAT\\. .{1,2} \\d{1,}")
  dfcc <- data.frame (c1 = cc, c2 = cc2)
  colnames(dfcc)[1] ="citation"
  cbc <- str_extract_all(case_df, "[:alpha:]{1,}\\.STAT\\. .{1,2} \\d{1,}")
  cbc2 <- str_locate_all(case_df, "[:alpha:]{1,}\\.STAT\\. .{1,2} \\d{1,}")
  dfcbc <- data.frame (c1 = cbc, c2 = cbc2)
  colnames(dfcbc)[1] ="citation"
  ccc <- str_extract_all(case_df, "[:alpha:]{1,}\\. Stat\\. .{1,2} \\d{1,}")
  ccc2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. Stat\\. .{1,2} \\d{1,}")
  dfccc <- data.frame (c1 = ccc, c2 = ccc2)
  colnames(dfccc)[1] ="citation"
  cbcc <- str_extract_all(case_df, "[:alpha:]{1,}\\.Stat\\. .{1,2} \\d{1,}")
  cbcc2 <- str_locate_all(case_df, "[:alpha:]{1,}\\.Stat\\. .{1,2} \\d{1,}")
  dfcbcc <- data.frame (c1 = cbcc, c2 = cbcc2)
  colnames(dfcbcc)[1] ="citation"
  cd <- str_extract_all(case_df, "[:alpha:]{1,}\\. ANN\\. .{1,2} \\d{1,}")
  cd2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. ANN\\. .{1,2} \\d{1,}")
  dfcd <- data.frame (c1 = cd, c2 = cd2)
  colnames(dfcd)[1] ="citation"
  ccdd <- str_extract_all(case_df, "[:alpha:]{1,}\\.ANN\\. .{1,2} \\d{1,}")
  ccdd2 <- str_locate_all(case_df, "[:alpha:]{1,}\\.ANN\\. .{1,2} \\d{1,}")
  dfccdd <- data.frame (c1 = ccdd, c2 = ccdd2)
  colnames(dfccdd)[1] ="citation"
  cdd <- str_extract_all(case_df, "[:alpha:]{1,}\\. [Aa]nn\\. .{1,2} \\d{1,}")
  cdd2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. [Aa]nn\\. .{1,2} \\d{1,}")
  dfcdd <- data.frame (c1 = cdd, c2 = cdd2)
  colnames(dfcdd)[1] ="citation"
  cddd <- str_extract_all(case_df, "[:alpha:]{1,}\\.[Aa]nn\\. .{1,2} \\d{1,}")
  cddd2 <- str_locate_all(case_df, "[:alpha:]{1,}\\.[Aa]nn\\. .{1,2} \\d{1,}")
  dfcddd <- data.frame (c1 = cddd, c2 = cddd2)
  colnames(dfcddd)[1] ="citation"
  bzz <- str_extract_all(case_df, "[:alpha:]\\.A\\. .{1,2} \\d{1,}")
  bzz2 <- str_locate_all(case_df, "[:alpha:]\\.A\\. .{1,2} \\d{1,}")
  dfbzz <- data.frame (c1 = bzz, c2 = bzz2)
  colnames(dfbzz)[1] ="citation"
  ce <- str_extract_all(case_df, "I\\. R\\. C\\. .{1,2} \\d{1,}")
  ce2 <- str_locate_all(case_df, "I\\. R\\. C\\. .{1,2} \\d{1,}")
  dfce <- data.frame (c1 = ce, c2 = ce2)
  colnames(dfce)[1] ="citation"
  cmm <- str_extract_all(case_df, "I\\.R\\.C\\. .{1,2} \\d{1,}")
  cmm2 <- str_locate_all(case_df, "I\\.R\\.C\\. .{1,2} \\d{1,}")
  dfcmm <- data.frame (c1 = cmm, c2 = cmm2)
  colnames(dfcmm)[1] ="citation"
  cf <- str_extract_all(case_df, "H\\.R\\. \\d{1,}[:punct:]")
  cf2 <- str_locate_all(case_df, "H\\.R\\. \\d{1,}[:punct:]")
  dfcf <- data.frame (c1 = cf, c2 = cf2)
  colnames(dfcf)[1] ="citation"
  cg <- str_extract_all(case_df, "S\\.R\\. \\d{1,}[:punct:]")
  cg2 <- str_locate_all(case_df, "S\\.R\\. \\d{1,}[:punct:]")
  dfcg <- data.frame (c1 = cg, c2 = cg2)
  colnames(dfcg)[1] ="citation"
  ch <- str_extract_all(case_df, "H\\. R\\. \\d{1,}[:punct:]")
  ch2 <- str_locate_all(case_df, "H\\. R\\. \\d{1,}[:punct:]")
  dfch <- data.frame (c1 = ch, c2 = ch2)
  colnames(dfch)[1] ="citation"
  ci <- str_extract_all(case_df, "S\\. R\\. \\d{1,}[:punct:]")
  ci2 <- str_locate_all(case_df, "S\\. R\\. \\d{1,}[:punct:]")
  dfci <- data.frame (c1 = ci, c2 = ci2)
  colnames(dfci)[1] ="citation"
  cj <- str_extract_all(case_df, "Res\\. \\d{1,}[:punct:]")
  cj2 <- str_locate_all(case_df, "Res\\. \\d{1,}[:punct:]")
  dfcj <- data.frame (c1 = cj, c2 = cj2)
  colnames(dfcj)[1] ="citation"
  ck <- str_extract_all(case_df, "REP\\. NO\\. \\d{1,}[:punct:]\\d{1,}")
  ck2 <- str_locate_all(case_df, "REP\\. NO\\. \\d{1,}[:punct:]\\d{1,}")
  dfck <- data.frame (c1 = ck, c2 = ck2)
  colnames(dfck)[1] ="citation"
  cl <- str_extract_all(case_df, "DOC\\. NO\\. \\d{1,}[:punct:]\\d{1,}")
  cl2 <- str_locate_all(case_df, "DOC\\. NO\\. \\d{1,}[:punct:]\\d{1,}")
  dfcl <- data.frame (c1 = cl, c2 = cl2)
  colnames(dfcl)[1] ="citation"
  cm <- str_extract_all(case_df, "\\d{1,} CONG\\. REC\\. [:graph:]")
  cm2 <- str_locate_all(case_df, "\\d{1,} CONG\\. REC\\. [:graph:]")
  dfcm <- data.frame (c1 = cm, c2 = cm2)
  colnames(dfcm)[1] ="citation"
  crr <- str_extract_all(case_df, "Fed\\. R\\. Civ\\. P\\. \\d{1,}")
  crr2 <- str_locate_all(case_df, "Fed\\. R\\. Civ\\. P\\. \\d{1,}")
  dfcrr <- data.frame (c1 = crr, c2 = crr2)
  colnames(dfcrr)[1] ="citation"
  crrr <- str_extract_all(case_df, "Fed\\.R\\.Civ\\.P\\. \\d{1,}")
  crrr2 <- str_locate_all(case_df, "Fed\\.R\\.Civ\\.P\\. \\d{1,}")
  dfcrrr <- data.frame (c1 = crrr, c2 = crrr2)
  colnames(dfcrrr)[1] ="citation"
  ha <- str_extract_all(case_df, "FED\\.R\\.CIV\\.P\\. \\d{1,}")
  ha2 <- str_locate_all(case_df, "FED\\.R\\.CIV\\.P\\. \\d{1,}")
  dfha <- data.frame (c1 = ha, c2 = ha2)
  colnames(dfha)[1] ="citation"
  hb <- str_extract_all(case_df, "FED\\. R\\. CIV\\. P\\. \\d{1,}")
  hb2 <- str_locate_all(case_df, "FED\\. R\\. CIV\\. P\\. \\d{1,}")
  dfhb <- data.frame (c1 = hb, c2 = hb2)
  colnames(dfhb)[1] ="citation"
  hc <- str_extract_all(case_df, "Fed\\.R\\.Civ\\.P\\. \\d{1,}")
  hc2 <- str_locate_all(case_df, "Fed\\.R\\.Civ\\.P\\. \\d{1,}")
  dfhc <- data.frame (c1 = hc, c2 = hc2)
  colnames(dfhc)[1] ="citation"
  hh <- str_extract_all(case_df, "Rep\\. No\\. \\d{1,}")
  hh2 <- str_locate_all(case_df, "Rep\\. No\\. \\d{1,}")
  dfhh <- data.frame (c1 = hh, c2 = hh2)
  colnames(dfhh)[1] ="citation"
  hi <- str_extract_all(case_df, "Doc\\. No\\. \\d{1,}")
  hi2 <- str_locate_all(case_df, "Doc\\. No\\. \\d{1,}")
  dfhi <- data.frame (c1 = hi, c2 = hi2)
  colnames(dfhi)[1] ="citation"
  hj <- str_extract_all(case_df, "\\d{1,} Cong\\. Rec\\. [:graph:]")
  hj2 <- str_locate_all(case_df, "\\d{1,} Cong\\. Rec\\. [:graph:]")
  dfhj <- data.frame (c1 = hj, c2 = hj2)
  colnames(dfhj)[1] ="citation"
  hk <- str_extract_all(case_df, "Gen\\. Laws ch\\.")
  hk2 <- str_locate_all(case_df, "Gen\\. Laws ch\\.")
  dfhk <- data.frame (c1 = hk, c2 = hk2)
  colnames(dfhk)[1] ="citation"
  hl <- str_extract_all(case_df, "Gen\\. Laws chs\\.")
  hl2 <- str_locate_all(case_df, "Gen\\. Laws chs\\.")
  dfhl <- data.frame (c1 = hl, c2 = hl2)
  colnames(dfhl)[1] ="citation"
  hm <- str_extract_all(case_df, "Rev\\.Code")
  hm2 <- str_locate_all(case_df, "Rev\\.Code")
  dfhm<- data.frame (c1 = hm, c2 = hm2)
  colnames(dfhm)[1] ="citation"

  #agencies
  cn <- str_extract_all(case_df, "\\d{1,} C\\. F\\. R\\. .{1,2} \\d{1,}")
  cn2 <- str_locate_all(case_df, "\\d{1,} C\\. F\\. R\\. .{1,2} \\d{1,}")
  dfcn <- data.frame (c1 = cn, c2 = cn2)
  colnames(dfcn)[1] ="citation"
  co <- str_extract_all(case_df, "\\d{1,} Fed\\. Reg\\. .{1,2} \\d{1,}")
  co2 <- str_locate_all(case_df, "\\d{1,} Fed\\. Reg\\. .{1,2} \\d{1,}")
  dfco <- data.frame (c1 = co, c2 = co2)
  colnames(dfco)[1] ="citation"
  cnn <- str_extract_all(case_df, "\\d{1,} C\\.F\\.R\\. .{1,2} \\d{1,}")
  cnn2 <- str_locate_all(case_df, "\\d{1,} C\\.F\\.R\\. .{1,2} \\d{1,}")
  dfcnn <- data.frame (c1 = cnn, c2 = cnn2)
  colnames(dfcnn)[1] ="citation"
  coo <- str_extract_all(case_df, "\\d{1,} Fed\\.Reg\\. .{1,2} \\d{1,}")
  coo2 <- str_locate_all(case_df, "\\d{1,} Fed\\.Reg\\. .{1,2} \\d{1,}")
  dfcoo <- data.frame (c1 = coo, c2 = coo2)
  colnames(dfcoo)[1] ="citation"
  cnnn <- str_extract_all(case_df, "\\d{1,} C\\.F\\.R\\. at \\d{1,}")
  cnnn2 <- str_locate_all(case_df, "\\d{1,} C\\.F\\.R\\. at \\d{1,}")
  dfcnnn <- data.frame (c1 = cnnn, c2 = cnnn2)
  colnames(dfcnnn)[1] ="citation"
  cooo <- str_extract_all(case_df, "\\d{1,} Fed\\.Reg\\. at \\d{1,}")
  cooo2 <- str_locate_all(case_df, "\\d{1,} Fed\\.Reg\\. at \\d{1,}")
  dfcooo <- data.frame (c1 = cooo, c2 = cooo2)
  colnames(dfcooo)[1] ="citation"
  cll <- str_extract_all(case_df, "Treasury Regulation .{1,2} \\d{1,}")
  cll2 <- str_locate_all(case_df, "Treasury Regulation .{1,2} \\d{1,}")
  dfcll <- data.frame (c1 = cll, c2 = cll2)
  colnames(dfcll)[1] ="citation"
  hd <- str_extract_all(case_df, "\\d{1,} C\\.F\\.R\\. sec\\. \\d{1,}")
  hd2 <- str_locate_all(case_df, "\\d{1,} C\\.F\\.R\\. sec\\. \\d{1,}")
  dfhd <- data.frame (c1 = hd, c2 = hd2)
  colnames(dfhd)[1] ="citation"
  he <- str_extract_all(case_df, "\\d{1,} C\\.F\\.R\\. \\d{1,}")
  he2 <- str_locate_all(case_df, "\\d{1,} C\\.F\\.R\\. \\d{1,}")
  dfhe <- data.frame (c1 = he, c2 = he2)
  colnames(dfhe)[1] ="citation"
  hf <- str_extract_all(case_df, "\\d{1,} C\\. F\\. R\\. sec\\. \\d{1,}")
  hf2 <- str_locate_all(case_df, "\\d{1,} C\\. F\\. R\\. sec\\. \\d{1,}")
  dfhf <- data.frame (c1 = hf, c2 = hf2)
  colnames(dfhf)[1] ="citation"
  hg <- str_extract_all(case_df, "\\d{1,} C\\. F\\. R\\. \\d{1,}")
  hg2 <- str_locate_all(case_df, "\\d{1,} C\\. F\\. R\\. \\d{1,}")
  dfhg <- data.frame (c1 = hg, c2 = hg2)
  colnames(dfhg)[1] ="citation"

  #nonprecedential (part 1)
  cp <- str_extract_all(case_df, "RESTATEMENT [:graph:] [:alpha:]{1,}")
  cp2 <- str_locate_all(case_df, "RESTATEMENT [:graph:] [:alpha:]{1,}")
  dfcp <- data.frame (c1 = cp, c2 = cp2)
  colnames(dfcp)[1] ="citation"
  cpp <- str_extract_all(case_df, "Restatement \\([:alpha:]{1,}\\) of [:alpha:]{1,}")
  cpp2 <- str_locate_all(case_df, "Restatement \\([:alpha:]{1,}\\) of [:alpha:]{1,}")
  dfcpp <- data.frame (c1 = cpp, c2 = cpp2)
  colnames(dfcpp)[1] ="citation"
  cppp <- str_extract_all(case_df, "RESTATEMENT \\([:alpha:]{1,}\\) OF [:alpha:]{1,}")
  cppp2 <- str_locate_all(case_df, "RESTATEMENT \\([:alpha:]{1,}\\) OF [:alpha:]{1,}")
  dfcppp <- data.frame (c1 = cppp, c2 = cppp2)
  colnames(dfcppp)[1] ="citation"
  cqq <- str_extract_all(case_df, "Federal Practice and Procedure")
  cqq2 <- str_locate_all(case_df, "Federal Practice and Procedure")
  dfcqq <- data.frame (c1 = cqq, c2 = cqq2)
  colnames(dfcqq)[1] ="citation"
  ia <- str_extract_all(case_df, "Federal Practice . Procedure")
  ia2 <- str_locate_all(case_df, "Federal Practice . Procedure")
  dfia <- data.frame (c1 = ia, c2 = ia2)
  colnames(dfia)[1] ="citation"
  ib <- str_extract_all(case_df, "FEDERAL PRACTICE . PROCEDURE")
  ib2 <- str_locate_all(case_df, "FEDERAL PRACTICE . PROCEDURE")
  dfib <- data.frame (c1 = ib, c2 = ib2)
  colnames(dfib)[1] ="citation"
  ic <- str_extract_all(case_df, "FEDERAL PRACTICE AND PROCEDURE")
  ic2 <- str_locate_all(case_df, "FEDERAL PRACTICE AND PROCEDURE")
  dfic <- data.frame (c1 = ic, c2 = ic2)
  colnames(dfic)[1] ="citation"

  #citations to case records from the initial trial
  cq <- str_extract_all(case_df, "Brief of [:alpha:]{1,} at \\d{1,}")
  cq2 <- str_locate_all(case_df, "Brief of [:alpha:]{1,} at \\d{1,}")
  dfcq <- data.frame (c1 = cq, c2 = cq2)
  colnames(dfcq)[1] ="citation"
  cr <- str_extract_all(case_df, "Transcript of [:alpha:]{1,} at \\d{1,}")
  cr2 <- str_locate_all(case_df, "Transcript of [:alpha:]{1,} at \\d{1,}")
  dfcr <- data.frame (c1 = cr, c2 = cr2)
  colnames(dfcr)[1] ="citation"
  cs <- str_extract_all(case_df, "Oral Argument at \\d{1,}")
  cs2 <- str_locate_all(case_df, "Oral Argument at \\d{1,}")
  dfcs <- data.frame (c1 = cs, c2 = cs2)
  colnames(dfcs)[1] ="citation"
  ct <- str_extract_all(case_df, "Motion for [:alpha:]{1,} at \\d{1,}")
  ct2 <- str_locate_all(case_df, "Motion for [:alpha:]{1,} at \\d{1,}")
  dfct <- data.frame (c1 = ct, c2 = ct2)
  colnames(dfct)[1] ="citation"
  cu <- str_extract_all(case_df, "[:alpha:]{1,} Br\\. \\d{1,}")
  cu2 <- str_locate_all(case_df, "[:alpha:]{1,} Br\\. \\d{1,}")
  dfcu <- data.frame (c1 = cu, c2 = cu2)
  colnames(dfcu)[1] ="citation"
  cv <- str_extract_all(case_df, "[:alpha:]{1,} Tr\\. \\d{1,}")
  cv2 <- str_locate_all(case_df, "[:alpha:]{1,} Tr\\. \\d{1,}")
  dfcv <- data.frame (c1 = cv, c2 = cv2)
  colnames(dfcv)[1] ="citation"
  cw <- str_extract_all(case_df, "Oral Arg\\. \\d{1,}")
  cw2 <- str_locate_all(case_df, "Oral Arg\\. \\d{1,}")
  dfcw <- data.frame (c1 = cw, c2 = cw2)
  colnames(dfcw)[1] ="citation"
  cx <- str_extract_all(case_df, "[:alpha:]{1,} Mot\\. \\d{1,}")
  cx2 <- str_locate_all(case_df, "[:alpha:]{1,} Mot\\. \\d{1,}")
  dfcx <- data.frame (c1 = cx, c2 = cx2)
  colnames(dfcx)[1] ="citation"

  legis_df <- data.frame(matrix(ncol = 3, nrow = 0))
  legis_df <- rbind(dfbu, dfbv, dfbw, dfbx, dfby, dfbz, dfca, dfcb, dfcc, dfcd, dfccc,
                    dfce, dfcf, dfcg, dfch, dfci, dfcj, dfck, dfcl, dfcm, dfcn, dfco,
                    dfcq, dfcr, dfcs, dfct, dfcu, dfcv, dfcw, dfcx, dfbuu, dfbvv, dfbww,
                    dfbxx, dfcbb, dfcdd, dfcrr, dfcnn, dfcoo, dfcll, dfcmm, dfcnnn, dfcooo,
                    dfcrrr, dfcaa, dfcbbb, dfcbc, dfcbcc, dfccdd, dfcddd, dfbzz, dfha,
                    dfhb, dfhc, dfhd, dfhe, dfhf, dfhg, dfhh, dfhi, dfhj, dfhk, dfhl, dfhm,
                    dfhn)
  legis_df <- legis_df %>% mutate(type = "authority")

  # citations to law reviews
  cy <- str_extract_all(case_df, "[:alpha:]{1,}\\. Rev\\. \\d{1,}")
  cy2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. Rev\\. \\d{1,}")
  dfcy <- data.frame (c1 = cy, c2 = cy2)
  colnames(dfcy)[1] ="citation"
  cz <- str_extract_all(case_df, "[:alpha:]{1,}\\.Rev\\. \\d{1,}")
  cz2 <- str_locate_all(case_df, "[:alpha:]{1,}\\.Rev\\. \\d{1,}")
  dfcz <- data.frame (c1 = cz, c2 = cz2)
  colnames(dfcz)[1] ="citation"
  da <- str_extract_all(case_df, "J\\. Sci\\. . Tech\\. \\d{1,}")
  da2 <- str_locate_all(case_df, "J\\. Sci\\. . Tech\\. \\d{1,}")
  dfda <- data.frame (c1 = da, c2 = da2)
  colnames(dfda)[1] ="citation"
  db <- str_extract_all(case_df, "[:alpha:]{1,}\\. L\\.J\\. \\d{1,}")
  db2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. L\\.J\\. \\d{1,}")
  dfdb <- data.frame (c1 = db, c2 = db2)
  colnames(dfdb)[1] ="citation"
  dc <- str_extract_all(case_df, "[:alpha:]{1,}\\. L\\. J\\. \\d{1,}")
  dc2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. L\\. J\\. \\d{1,}")
  dfdc <- data.frame (c1 = dc, c2 = dc2)
  colnames(dfdc)[1] ="citation"
  dd <- str_extract_all(case_df, "[:alpha:]{1,}\\. . Pol[:punct:]y \\d{1,}")
  dd2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. . Pol[:punct:]y \\d{1,}")
  dfdd <- data.frame (c1 = dd, c2 = dd2)
  colnames(dfdd)[1] ="citation"
  de <- str_extract_all(case_df, "[:alpha:]{1,}\\. . Pol[:punct:]y [:alpha:]{1,}\\. \\d{1,}")
  de2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. . Pol[:punct:]y [:alpha:]{1,}\\. \\d{1,}")
  dfde <- data.frame (c1 = de, c2 = de2)
  colnames(dfde)[1] ="citation"
  df <- str_extract_all(case_df, "J\\. Int[:punct:]l [:alpha:]{1,}\\. \\d{1,}")
  df2 <- str_locate_all(case_df, "J\\. Int[:punct:]l [:alpha:]{1,}\\. \\d{1,}")
  dfdf <- data.frame (c1 = df, c2 = df2)
  colnames(dfdf)[1] ="citation"
  dg <- str_extract_all(case_df, "[:alpha:]{1,} J\\. L\\. \\d{1,}")
  dg2 <- str_locate_all(case_df, "[:alpha:]{1,} J\\. L\\. \\d{1,}")
  dfdg <- data.frame (c1 = dg, c2 = dg2)
  colnames(dfdg)[1] ="citation"
  dh <- str_extract_all(case_df, "[:alpha:]{1,}\\. [:alpha:]{1,}\\. L\\. \\d{1,}")
  dh2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. [:alpha:]{1,}\\. L\\. \\d{1,}")
  dfdh <- data.frame (c1 = dh, c2 = dh2)
  colnames(dfdh)[1] ="citation"
  di <- str_extract_all(case_df, "[:alpha:]{1,}\\. L\\.Q\\. \\d{1,}")
  di2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. L\\.Q\\. \\d{1,}")
  dfdi <- data.frame (c1 = di, c2 = di2)
  colnames(dfdi)[1] ="citation"
  dj <- str_extract_all(case_df, ". [:alpha:]{1,}\\. L\\. \\d{1,}")
  dj2 <- str_locate_all(case_df, ". [:alpha:]{1,}\\. L\\. \\d{1,}")
  dfdj <- data.frame (c1 = dj, c2 = dj2)
  colnames(dfdj)[1] ="citation"
  dk <- str_extract_all(case_df, "[:alpha:]{1,} Rev\\. \\d{1,}")
  dk2 <- str_locate_all(case_df, "[:alpha:]{1,} Rev\\. \\d{1,}")
  dfdk <- data.frame (c1 = dk, c2 = dk2)
  colnames(dfdk)[1] ="citation"
  dl <- str_extract_all(case_df, "Int'l [:alpha:]{1,}\\. \\d{1,}")
  dl2 <- str_locate_all(case_df, "Int'l [:alpha:]{1,}\\. \\d{1,}")
  dfdl <- data.frame (c1 = dl, c2 = dl2)
  colnames(dfdl)[1] ="citation"
  dm <- str_extract_all(case_df, "[:alpha:]{1,}\\. J\\. \\d{1,}")
  dm2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. J\\. \\d{1,}")
  dfdm <- data.frame (c1 = dm, c2 = dm2)
  colnames(dfdm)[1] ="citation"
  dn <- str_extract_all(case_df, "Gender . L\\. \\d{1,}")
  dn2 <- str_locate_all(case_df, "Gender . L\\. \\d{1,}")
  dfdn <- data.frame (c1 = dn, c2 = dn2)
  colnames(dfdn)[1] ="citation"
  do <- str_extract_all(case_df, "Women . L\\. \\d{1,}")
  do2 <- str_locate_all(case_df, "Women . L\\. \\d{1,}")
  dfdo <- data.frame (c1 = do, c2 = do2)
  colnames(dfdo)[1] ="citation"
  dp <- str_extract_all(case_df, "Race . L\\. \\d{1,}")
  dp2 <- str_locate_all(case_df, "Race . L\\. \\d{1,}")
  dfdp <- data.frame (c1 = dp, c2 = dp2)
  colnames(dfdp)[1] ="citation"
  dq <- str_extract_all(case_df, "Sports . L\\. \\d{1,}")
  dq2 <- str_locate_all(case_df, "Sports . L\\. \\d{1,}")
  dfdq <- data.frame (c1 = dq, c2 = dq2)
  colnames(dfdq)[1] ="citation"
  dr <- str_extract_all(case_df, "Med\\. . L\\. \\d{1,}")
  dr2 <- str_locate_all(case_df, "Med\\. . L\\. \\d{1,}")
  dfdr <- data.frame (c1 = dr, c2 = dr2)
  colnames(dfdr)[1] ="citation"
  ds <- str_extract_all(case_df, "Sci\\. . L\\. \\d{1,}")
  ds2 <- str_locate_all(case_df, "Sci\\. . L\\. \\d{1,}")
  dfds <- data.frame (c1 = ds, c2 = ds2)
  colnames(dfds)[1] ="citation"
  dt <- str_extract_all(case_df, "L\\. . Tech\\. \\d{1,}")
  dt2 <- str_locate_all(case_df, "L\\. . Tech\\. \\d{1,}")
  dfdt <- data.frame (c1 = dt, c2 = dt2)
  colnames(dfdt)[1] ="citation"
  du <- str_extract_all(case_df, "[:alpha:]{1,}\\. L\\.F\\. \\d{1,}")
  du2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. L\\.F\\. \\d{1,}")
  dfdu <- data.frame (c1 = du, c2 = du2)
  colnames(dfdu)[1] ="citation"
  dv <- str_extract_all(case_df, "Health L\\. \\d{1,}")
  dv2 <- str_locate_all(case_df, "Health L\\. \\d{1,}")
  dfdv <- data.frame (c1 = dv, c2 = dv2)
  colnames(dfdv)[1] ="citation"
  dw <- str_extract_all(case_df, "J\\. Health Care L\\. \\d{1,}")
  dw2 <- str_locate_all(case_df, "J\\. Health Care L\\. \\d{1,}")
  dfdw <- data.frame (c1 = dw, c2 = dw2)
  colnames(dfdw)[1] ="citation"
  dx <- str_extract_all(case_df, "Legal Stud\\. \\d{1,}")
  dx2 <- str_locate_all(case_df, "Legal Stud\\. \\d{1,}")
  dfdx <- data.frame (c1 = dx, c2 = dx2)
  colnames(dfdx)[1] ="citation"
  dy <- str_extract_all(case_df, "L\\. Rep\\. \\d{1,}")
  dy2 <- str_locate_all(case_df, "L\\. Rep\\. \\d{1,}")
  dfdy <- data.frame (c1 = dy, c2 = dy2)
  colnames(dfdy)[1] ="citation"
  dz <- str_extract_all(case_df, "Prac\\. . Proc\\.")
  dz2 <- str_locate_all(case_df, "Prac\\. . Proc\\.")
  dfdz <- data.frame (c1 = dz, c2 = dz2)
  colnames(dfdz)[1] ="citation"
  ea <- str_extract_all(case_df, "J\\.L\\. . [:alpha:]{1,} \\d{1,}")
  ea2 <- str_locate_all(case_df, "J\\.L\\. . [:alpha:]{1,} \\d{1,}")
  dfea <- data.frame (c1 = ea, c2 = ea2)
  colnames(dfea)[1] ="citation"
  eb <- str_extract_all(case_df, "J\\.L\\. . [:alpha:]{1,}\\. \\d{1,}")
  eb2 <- str_locate_all(case_df, "J\\.L\\. . [:alpha:]{1,}\\. \\d{1,}")
  dfeb <- data.frame (c1 = eb, c2 = eb2)
  colnames(dfeb)[1] ="citation"
  ec <- str_extract_all(case_df, "J\\.L\\. . [:alpha:]{1,}\\. [:alpha:]{1,}\\. \\d{1,}")
  ec2 <- str_locate_all(case_df, "J\\.L\\. . [:alpha:]{1,}\\. [:alpha:]{1,}\\. \\d{1,}")
  dfec <- data.frame (c1 = ec, c2 = ec2)
  colnames(dfec)[1] ="citation"
  ed <- str_extract_all(case_df, "J\\.L\\. . [:alpha:]{1,} [:alpha:]{1,}\\. \\d{1,}")
  ed2 <- str_locate_all(case_df, "J\\.L\\. . [:alpha:]{1,} [:alpha:]{1,}\\. \\d{1,}")
  dfed <- data.frame (c1 = ed, c2 = ed2)
  colnames(dfed)[1] ="citation"
  ee <- str_extract_all(case_df, "[:alpha:]{1,} L\\.Q\\. \\d{1,}")
  ee2 <- str_locate_all(case_df, "[:alpha:]{1,} L\\.Q\\. \\d{1,}")
  dfee <- data.frame (c1 = ee, c2 = ee2)
  colnames(dfee)[1] ="citation"
  ef <- str_extract_all(case_df, "J\\. Transnat[:punct:]l L\\. \\d{1,}")
  ef2 <- str_locate_all(case_df, "J\\. Transnat[:punct:]l L\\. \\d{1,}")
  dfef <- data.frame (c1 = ef, c2 = ef2)
  colnames(dfef)[1] ="citation"
  eg <- str_extract_all(case_df, "Contemp\\. Probs\\. \\d{1,}")
  eg2 <- str_locate_all(case_df, "Contemp\\. Probs\\. \\d{1,}")
  dfeg <- data.frame (c1 = eg, c2 = eg2)
  colnames(dfeg)[1] ="citation"
  eh <- str_extract_all(case_df, "Contemp\\. Legal Issues \\d{1,}")
  eh2 <- str_locate_all(case_df, "Contemp\\. Legal Issues \\d{1,}")
  dfeh <- data.frame (c1 = eh, c2 = eh2)
  colnames(dfeh)[1] ="citation"
  ei <- str_extract_all(case_df, "[:alpha:]{1,}\\. L\\. Ann\\. \\d{1,}")
  ei2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. L\\. Ann\\.\\d{1,}")
  dfei <- data.frame (c1 = ei, c2 = ei2)
  colnames(dfei)[1] ="citation"
  ej <- str_extract_all(case_df, "[:alpha:]{1,}\\. L\\. . [:alpha:]{1,} \\d{1,}")
  ej2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. L\\. . [:alpha:]{1,} \\d{1,}")
  dfej <- data.frame (c1 = ej, c2 = ej2)
  colnames(dfej)[1] ="citation"
  ek <- str_extract_all(case_df, "[:alpha:]{1,}\\. L\\. . [:alpha:]{1,}\\. \\d{1,}")
  ek2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. L\\. . [:alpha:]{1,}\\. \\d{1,}")
  dfek <- data.frame (c1 = ek, c2 = ek2)
  colnames(dfek)[1] ="citation"
  el <- str_extract_all(case_df, "[:alpha:]{1,} L\\. . [:alpha:]{1,}\\. \\d{1,}")
  el2 <- str_locate_all(case_df, "[:alpha:]{1,} L\\. . [:alpha:]{1,}\\. \\d{1,}")
  dfel <- data.frame (c1 = el, c2 = el2)
  colnames(dfel)[1] ="citation"
  em <- str_extract_all(case_df, "Int’l L\\. . [:alpha:]{1,}\\. \\d{1,}")
  em2 <- str_locate_all(case_df, "Int’l L\\. . [:alpha:]{1,}\\. \\d{1,}")
  dfem <- data.frame (c1 = em, c2 = em2)
  colnames(dfem)[1] ="citation"
  en <- str_extract_all(case_df, "Int’l L\\. . Com\\. Reg\\. \\d{1,}")
  en2 <- str_locate_all(case_df, "Int’l L\\. . Com\\. Reg\\. \\d{1,}")
  dfen <- data.frame (c1 = en, c2 = en2)
  colnames(dfen)[1] ="citation"
  eo <- str_extract_all(case_df, "Int’l L\\. . Foreign Aff\\. \\d{1,}")
  eo2 <- str_locate_all(case_df, "Int’l L\\. . Foreign Aff\\. \\d{1,}")
  dfeo <- data.frame (c1 = eo, c2 = eo2)
  colnames(dfeo)[1] ="citation"
  ep <- str_extract_all(case_df, "Rev\\. L\\. . Soc. Change \\d{1,}")
  ep2 <- str_locate_all(case_df, "Rev\\. L\\. . Soc. Change \\d{1,}")
  dfep <- data.frame (c1 = ep, c2 = ep2)
  colnames(dfep)[1] ="citation"
  eq <- str_extract_all(case_df, "Rev\\. L\\. . Women[:punct:]s Stud. \\d{1,}")
  eq2 <- str_locate_all(case_df, "Rev\\. L\\. . Women[:punct:]s Stud. \\d{1,}")
  dfeq <- data.frame (c1 = eq, c2 = eq2)
  colnames(dfeq)[1] ="citation"
  er <- str_extract_all(case_df, "[:alpha:]{1,}\\. [:alpha:]{1,} L. \\d{1,}")
  er2 <- str_locate_all(case_df, "[:alpha:]{1,}\\. [:alpha:]{1,} L. \\d{1,}")
  dfer <- data.frame (c1 = er, c2 = er2)
  colnames(dfer)[1] ="citation"
  es <- str_extract_all(case_df, "[:alpha:]{1,} [:alpha:]{1,}\\. L. \\d{1,}")
  es2 <- str_locate_all(case_df, "[:alpha:]{1,} [:alpha:]{1,}\\. L. \\d{1,}")
  dfes <- data.frame (c1 = es, c2 = es2)
  colnames(dfes)[1] ="citation"
  et <- str_extract_all(case_df, "J\\. Tax[:punct:]n \\d{1,}")
  et2 <- str_locate_all(case_df, "J\\. Tax[:punct:]n \\d{1,}")
  dfet <- data.frame (c1 = et, c2 = et2)
  colnames(dfet)[1] ="citation"
  eu <- str_extract_all(case_df, "J\\. Corp\\. Tax[:punct:]n \\d{1,}")
  eu2 <- str_locate_all(case_df, "J\\. Corp\\. Tax[:punct:]n \\d{1,}")
  dfeu <- data.frame (c1 = eu, c2 = eu2)
  colnames(dfeu)[1] ="citation"
  ev <- str_extract_all(case_df, "Am\\. J\\. Juris\\. \\d{1,}")
  ev2 <- str_locate_all(case_df, "Am\\. J\\. Juris\\. \\d{1,}")
  dfev <- data.frame (c1 = ev, c2 = ev2)
  colnames(dfev)[1] ="citation"
  ew <- str_extract_all(case_df, "Am\\. J\\. [:alpha:]{1,} [:alpha:]{1,}\\. \\d{1,}")
  ew2 <- str_locate_all(case_df, "Am\\. J\\. [:alpha:]{1,} [:alpha:]{1,}\\. \\d{1,}")
  dfew <- data.frame (c1 = ew, c2 = ew2)
  colnames(dfew)[1] ="citation"
  ex <- str_extract_all(case_df, "J\\. Legis\\. \\d{1,}")
  ex2 <- str_locate_all(case_df, "J\\. Legis\\. \\d{1,}")
  dfex <- data.frame (c1 = ex, c2 = ex2)
  colnames(dfex)[1] ="citation"
  ey <- str_extract_all(case_df, "J\\. [:alpha:]{1,}\\. [:alpha:]{1,}\\. \\d{1,}")
  ey2 <- str_locate_all(case_df, "J\\. [:alpha:]{1,}\\. [:alpha:]{1,}\\. \\d{1,}")
  dfey <- data.frame (c1 = ey, c2 = ey2)
  colnames(dfey)[1] ="citation"
  ez <- str_extract_all(case_df, "J\\. Legal [:alpha:]{1,}\\. \\d{1,}")
  ez2 <- str_locate_all(case_df, "J\\. Legal [:alpha:]{1,}\\. \\d{1,}")
  dfez <- data.frame (c1 = ez, c2 = ez2)
  colnames(dfez)[1] ="citation"
  fa <- str_extract_all(case_df, "J\\.L\\. Soc[:punct:]y \\d{1,}")
  fa2 <- str_locate_all(case_df, "J\\.L\\. Soc[:punct:]y \\d{1,}")
  dffa <- data.frame (c1 = fa, c2 = fa2)
  colnames(dffa)[1] ="citation"
  fb <- str_extract_all(case_df, "Soc\\. Pol[:punct:]y . L\\. \\d{1,}")
  fb2 <- str_locate_all(case_df, "Soc\\. Pol[:punct:]y . L\\. \\d{1,}")
  dffb <- data.frame (c1 = fb, c2 = fb2)
  colnames(dffb)[1] ="citation"
  fc <- str_extract_all(case_df, "Law . Soc\\. Inquiry \\d{1,}")
  fc2 <- str_locate_all(case_df, "Law . Soc\\. Inquiry \\d{1,}")
  dffc <- data.frame (c1 = fc, c2 = fc2)
  colnames(dffc)[1] ="citation"
  fd <- str_extract_all(case_df, "L\\.J\\. Am\\. U\\. \\d{1,}")
  fd2 <- str_locate_all(case_df, "L\\.J\\. Am\\. U\\. \\d{1,}")
  dffd <- data.frame (c1 = fd, c2 = fd2)
  colnames(dffd)[1] ="citation"
  fe <- str_extract_all(case_df, "Yale J\\. on Reg\\. \\d{1,}")
  fe2 <- str_locate_all(case_df, "Yale J\\. on Reg\\. \\d{1,}")
  dffe <- data.frame (c1 = fe, c2 = fe2)
  colnames(dffe)[1] ="citation"
  ff <- str_extract_all(case_df, "Yale J\\. World Pub\\. Ord\\. \\d{1,}")
  ff2 <- str_locate_all(case_df, "Yale J\\. World Pub\\. Ord\\. \\d{1,}")
  dfff <- data.frame (c1 = ff, c2 = ff2)
  colnames(dfff)[1] ="citation"
  fg <- str_extract_all(case_df, "J\\.L\\. Reform \\d{1,}")
  fg2 <- str_locate_all(case_df, "J\\.L\\. Reform \\d{1,}")
  dffg <- data.frame (c1 = fg, c2 = fg2)
  colnames(dffg)[1] ="citation"
  fh <- str_extract_all(case_df, "Oil . Gas Tax Q\\. \\d{1,}")
  fh2 <- str_locate_all(case_df, "Oil . Gas Tax Q\\. \\d{1,}")
  dffh <- data.frame (c1 = fh, c2 = fh2)
  colnames(dffh)[1] ="citation"
  fi <- str_extract_all(case_df, "Hum\\. Rts\\. Q\\. \\d{1,}")
  fi2 <- str_locate_all(case_df, "Hum\\. Rts\\. Q\\. \\d{1,}")
  dffi <- data.frame (c1 = fi, c2 = fi2)
  colnames(dffi)[1] ="citation"
  fj <- str_extract_all(case_df, "Pol\\. . Soc\\. Sci\\. \\d{1,}")
  fj2 <- str_locate_all(case_df, "Pol\\. . Soc\\. Sci\\. \\d{1,}")
  dffj <- data.frame (c1 = fj, c2 = fj2)
  colnames(dffj)[1] ="citation"

  nonpreced_df <- data.frame(matrix(ncol = 3, nrow = 0))
  nonpreced_df <- rbind(dfcp, dfcy, dfcz, dfda, dfdb, dfdc, dfdd, dfde, dfdf,
                        dfdg, dfdh, dfdi, dfdj, dfdk, dfdl, dfdm, dfdn, dfdo,
                        dfdp, dfdq, dfdr, dfds, dfdt, dfdu, dfdv, dfdw, dfdx,
                        dfdy, dfdz, dfea, dfeb, dfec, dfed, dfee, dfef, dfeg,
                        dfeh, dfei, dfej, dfek, dfel, dfem, dfen, dfeo, dfep,
                        dfeq, dfer, dfes, dfet, dfeu, dfev, dfew, dfex, dfey,
                        dfez, dffa, dffb, dffc, dffd, dffe, dfff, dffg, dffh,
                        dffi, dffj, dfcpp, dfcqq, dfcppp, dfia, dfib, dfic)
  nonpreced_df <- nonpreced_df %>% mutate(type = "nonprecedential")

  #combining all dataframes
  final <- rbind(preced_df, ids_df, legis_df, nonpreced_df)

  #renaming the location columns
  colnames(final)[2] ="start"
  colnames(final)[3] ="end"

  #ordering my chronological location and deleting duplicate citations
  final <- final[order(final$start, decreasing = FALSE), ]
  final <- final[!duplicated(final$end),]
  final <- final[!duplicated(final$start),]

  #add the ids
  final = final %>% fill(type, .direction = "down")

  #----
  #finding the actual ciation to the given case
  raw_a1 <- str_extract_all(raw_data, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} U\\.S\\. \\d{1,}")
  raw_a2 <- str_locate_all(raw_data, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} U\\.S\\. \\d{1,}")
  rawa <- data.frame(c1 = raw_a1, c2 = raw_a2)
  colnames(rawa)[1] ="citation"
  raw_b1 <- str_extract_all(raw_data, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} S\\.Ct\\. \\d{1,}")
  raw_b2 <- str_locate_all(raw_data, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} S\\.Ct\\. \\d{1,}")
  rawb <- data.frame (c1 = raw_b1, c2 = raw_b2)
  colnames(rawb)[1] ="citation"
  raw_c1 <- str_extract_all(raw_data, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\. \\d{1,}")
  raw_c2 <- str_locate_all(raw_data, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\. \\d{1,}")
  rawc <- data.frame (c1 = raw_c1, c2 = raw_c2)
  colnames(rawc)[1] ="citation"
  raw_d1 <- str_extract_all(raw_data, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\.2d \\d{1,}")
  raw_d2 <- str_locate_all(raw_data, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\.2d \\d{1,}")
  rawd <- data.frame (c1 = raw_d1, c2 = raw_d2)
  colnames(rawd)[1] ="citation"
  raw_e1 <- str_extract_all(raw_data, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\.3d \\d{1,}")
  raw_e2 <- str_locate_all(raw_data, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\.3d \\d{1,}")
  rawe <- data.frame (c1 = raw_e1, c2 = raw_e2)
  colnames(rawe)[1] ="citation"
  raw_f1 <- str_extract_all(raw_data, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\.4th \\d{1,}")
  raw_f2 <- str_locate_all(raw_data, "[:alpha:]{1,}[:punct:]{1,} \\d{1,} F\\.4th \\d{1,}")
  rawf <- data.frame (c1 = raw_f1, c2 = raw_f2)
  colnames(rawf)[1] ="citation"

  names_df <- rbind(rawa, rawb, rawc, rawd, rawe, rawf)

  colnames(names_df)[2] ="start"
  colnames(names_df)[3] ="end"

  names_df <- names_df[order(names_df$start, decreasing = FALSE), ]
  names_df <- names_df[!duplicated(names_df$end),]

  #finally, I create a case-level dataset
  colnames(new)[1] ="cite"
  new$cite <- names_df$citation[1]
  final <- final[!(final$citation == new$cite),]
  new$preced_ct <- nrow(final[final$type == 'precedential', ])
  new$author_ct <- nrow(final[final$type == 'authority', ])
  new$nonpreced_ct <- nrow(final[final$type == 'nonprecedential', ])
  new$length <- str_count(case_df, '\\w+')
  new$year <- str_extract(raw_data, "\\(20\\d{2}\\)")

  return(new)
}

#----
#importing PDFs and running the function
setwd("C:\\Users\\atrip\\Downloads\\Tripp_TextAnalysis_Workshop\\PDFs")

filenames <- list.files(pattern="*.pdf", full.names=TRUE)

raw_data = list()
for (i in 1:5) {
  raw_data[i] <- paste0(pdf_text(pdf = filenames[i]), collapse = '')
}

df1 = data.frame()
for (i in 1:5) {
  print(sprintf("running megaman on %s", i))
  output <- megaman(raw_data[i])
  print(sprintf("running rbind on %s", i))
  df1 <- rbind(df1, output)
} #same as above note

#----
#here's a visual graph for average number of citations by type
suba <- subset(df1, select = c(2, 3))
suba$group <- "cases"
names(suba)[2] <- "citations"

subb <- subset(df1, select = c(2, 4))
subb$group <- "legal authority"
names(subb)[2] <- "citations"

subc <- subset(df1, select = c(2, 5))
subc$group <- "secondary sources"
names(subc)[2] <- "citations"

df2 <- rbind(suba, subb, subc)

ggplot(data=df2, mapping=aes(x=group, y=citations)) +
  labs(title="Average Citations by Type", x="", y="# citations") +
  theme_light() +
  stat_summary(fun.data=mean_sdl, geom="bar", position=position_dodge(width=0.95))  +
  scale_fill_manual(values = c("#414141", "#414141", "#414141")) +
  stat_summary(fun.data=mean_cl_boot, geom="errorbar", position=position_dodge(width=0.95), width=0.3) +
  theme(text=element_text(family="Times New Roman", face="bold", color="black", size=9)) +
  guides(fill = guide_legend(override.aes = list(pattern = c("none", "circle"), pattern_fill = c("black", "white"))))
